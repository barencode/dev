//
//  ViewController.swift
//  20_task
//
//  Created by Vladimir Minaev on 22.11.2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

